# An optional custom script to run before Hugo builds your site.
# You can delete it if you do not need it.
