function cleanForm() {
    document.getElementById("contact-form").reset();
}